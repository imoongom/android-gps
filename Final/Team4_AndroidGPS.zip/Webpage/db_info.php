<?php
$username="root";
$password="aman";
$database="androidgps";
?>